# Build SnapStep from your phone (no laptop)

This project includes a GitHub Actions workflow that builds a debug APK in the cloud.

1. Sign in to GitHub in your phone browser and create a new repository (Public or Private).
2. Upload the contents of this ZIP into the repository. Make sure `app/`, `build.gradle`,
   `settings.gradle`, `gradle.properties`, and `.github/` are at the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build SnapStep APK** and tap **Run workflow**.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, scroll to **Artifacts**, and download
   `SnapStep-debug-apk`.
7. Extract the downloaded artifact ZIP on your phone and install `app-debug.apk`.
8. If Android blocks installation, allow your browser or file manager to install unknown apps.

The build is unsigned with a personal release key and is a debug APK for testing only.
