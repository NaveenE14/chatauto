package com.example.snapstep

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 40)
        }

        val title = TextView(this).apply {
            text = "SnapStep — first-step test"
            textSize = 24f
        }
        val info = TextView(this).apply {
            text = "\nThis prototype opens Snapchat and can request one Add-button tap at a time. " +
                "You must review the account and confirm each action. It does not bulk-add users " +
                "or automatically cancel requests.\n"
            textSize = 16f
        }
        val open = Button(this).apply {
            text = "1. Open Snapchat"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.snapchat.android")
                if (launch != null) startActivity(launch)
                else Toast.makeText(this@MainActivity, "Snapchat is not installed.", Toast.LENGTH_LONG).show()
            }
        }
        val accessibility = Button(this).apply {
            text = "2. Enable SnapStep accessibility"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val tap = Button(this).apply {
            text = "3. Request ONE Add-button tap"
            setOnClickListener {
                SnapAccessibilityService.requestSingleAddTap()
                Toast.makeText(this@MainActivity,
                    "One-tap request queued. Switch to Snapchat and confirm the prompt.",
                    Toast.LENGTH_LONG).show()
            }
        }
        val footer = TextView(this).apply {
            text = "\nSafety: use only with accounts you choose. Snapchat UI changes can make controls unavailable. " +
                "This prototype is for a single manually confirmed action, not bulk friend requests."
            textSize = 13f
        }
        layout.addView(title); layout.addView(info); layout.addView(open)
        layout.addView(accessibility); layout.addView(tap); layout.addView(footer)
        setContentView(layout)
    }
}
