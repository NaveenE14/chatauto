package com.example.snapstep

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class SnapAccessibilityService : AccessibilityService() {
    @Volatile private var oneTapRequested = false
    private var promptView: LinearLayout? = null

    companion object {
        @Volatile private var instance: SnapAccessibilityService? = null
        fun requestSingleAddTap() { instance?.oneTapRequested = true }
    }

    override fun onServiceConnected() { instance = this }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!oneTapRequested || event == null) return
        if (event.packageName?.toString() != "com.snapchat.android") return

        val root = rootInActiveWindow ?: return
        val candidate = findAddButton(root) ?: return
        oneTapRequested = false

        Handler(Looper.getMainLooper()).post {
            showConfirmation(candidate)
        }
    }

    private fun showConfirmation(candidate: AccessibilityNodeInfo) {
        removePrompt()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 28, 36, 24)
            setBackgroundColor(0xFF252525.toInt())
        }
        panel.addView(TextView(this).apply {
            text = "SnapStep: Snapchat shows an Add button. Send this one friend request?"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "Cancel"
            setOnClickListener { removePrompt() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply {
            text = "Tap Add"
            setOnClickListener {
                val ok = candidate.refresh() && candidate.isVisibleToUser &&
                    candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                Toast.makeText(this@SnapAccessibilityService,
                    if (ok) "One tap sent." else "Button unavailable; no tap completed.",
                    Toast.LENGTH_SHORT).show()
                removePrompt()
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(actions)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(panel, params)
            promptView = panel
        } catch (_: Exception) {
            Toast.makeText(this, "Could not show confirmation. No action taken.",
                Toast.LENGTH_LONG).show()
        }
    }

    private fun removePrompt() {
        promptView?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
            catch (_: Exception) { }
        }
        promptView = null
    }

    private fun findAddButton(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if ((text == "Add" || desc == "Add") && node.isEnabled &&
            node.isClickable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findAddButton(child)
            if (found != null) return found
        }
        return null
    }

    override fun onInterrupt() { removePrompt() }
    override fun onDestroy() {
        removePrompt()
        instance = null
        super.onDestroy()
    }
}
