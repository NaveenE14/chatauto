# SnapStep (Android prototype)

This is a small Android Studio project for testing the first Snapchat interaction only.

## What it does
- Opens the installed Snapchat app.
- Lets the user enable an Android Accessibility Service.
- When the user requests it, searches the current Snapchat screen for an exact, clickable `Add` control.
- Shows a confirmation dialog and performs at most one tap.

## What it deliberately does not do
- No bulk friend requests, loops, scraping, or unattended actions.
- No automatic cancellation/removal of outgoing requests.
- No login handling or Snapchat security bypass.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync. Android SDK Platform 35 is required.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on your Android phone.
5. Open SnapStep, tap **Enable SnapStep accessibility**, and enable the service.
6. Return to SnapStep, open Snapchat, navigate to Add Friends, then return to SnapStep and request one tap. Keep the target Add button visible in Snapchat and confirm the prompt.

## Important limitations
Snapchat changes its UI frequently. If the visible control is not exposed to Android Accessibility as an exact clickable `Add` node, the helper will do nothing. The app requires the user to initiate and confirm each individual request. Review Snapchat's terms and applicable rules before using automation.
